import { useRef, useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";

interface PookalamLayer {
  type: 'center' | 'circle' | 'alternating';
  radius: number;
  color?: string;
  colors?: string[];
  flowerCount?: number;
  flowerSize?: number;
  petals?: number;
  innerColor?: string;
}

const pookalamConfig = {
  centerX: 300,
  centerY: 300,
  layers: [
    {
      type: 'center' as const,
      radius: 35,
      color: '#DC2626',
      petals: 8,
      innerColor: '#F59E0B'
    },
    {
      type: 'circle' as const,
      radius: 60,
      color: '#FFFFFF',
      flowerCount: 20,
      flowerSize: 7
    },
    {
      type: 'alternating' as const,
      radius: 85,
      colors: ['#DC2626', '#FFFFFF'],
      flowerCount: 28,
      flowerSize: 6
    },
    {
      type: 'circle' as const,
      radius: 110,
      color: '#F59E0B',
      flowerCount: 36,
      flowerSize: 6
    },
    {
      type: 'alternating' as const,
      radius: 135,
      colors: ['#FFFFFF', '#DC2626'],
      flowerCount: 44,
      flowerSize: 5
    },
    {
      type: 'circle' as const,
      radius: 160,
      color: '#FDE047',
      flowerCount: 52,
      flowerSize: 6
    },
    {
      type: 'alternating' as const,
      radius: 185,
      colors: ['#F59E0B', '#DC2626'],
      flowerCount: 60,
      flowerSize: 5
    },
    {
      type: 'circle' as const,
      radius: 210,
      color: '#FFFFFF',
      flowerCount: 68,
      flowerSize: 5
    },
    {
      type: 'circle' as const,
      radius: 235,
      color: '#F59E0B',
      flowerCount: 76,
      flowerSize: 6
    },
    {
      type: 'circle' as const,
      radius: 260,
      color: '#FDE047',
      flowerCount: 84,
      flowerSize: 5
    }
  ] as PookalamLayer[]
};

export function PookalamCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [animationRunning, setAnimationRunning] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const [progress, setProgress] = useState(0);
  const [statusText, setStatusText] = useState("Ready to begin");

  const drawFlower = (ctx: CanvasRenderingContext2D, x: number, y: number, size: number, color: string) => {
    ctx.save();
    ctx.translate(x, y);
    
    // Draw flower petals
    for (let i = 0; i < 5; i++) {
      ctx.beginPath();
      ctx.rotate(Math.PI * 2 / 5);
      ctx.ellipse(0, -size/2, size/4, size/2, 0, 0, Math.PI * 2);
      ctx.fillStyle = color;
      ctx.fill();
      ctx.strokeStyle = 'rgba(0,0,0,0.2)';
      ctx.lineWidth = 1;
      ctx.stroke();
    }
    
    // Center of flower
    ctx.beginPath();
    ctx.arc(0, 0, size/4, 0, Math.PI * 2);
    ctx.fillStyle = '#FDE047';
    ctx.fill();
    
    ctx.restore();
  };

  const drawCentralMotif = (ctx: CanvasRenderingContext2D) => {
    const config = pookalamConfig.layers[0];
    const centerX = pookalamConfig.centerX;
    const centerY = pookalamConfig.centerY;
    
    // Draw central geometric pattern
    ctx.beginPath();
    ctx.arc(centerX, centerY, config.radius, 0, Math.PI * 2);
    ctx.fillStyle = config.color!;
    ctx.fill();
    
    // Add geometric petals
    ctx.save();
    ctx.translate(centerX, centerY);
    for (let i = 0; i < config.petals!; i++) {
      ctx.rotate(Math.PI * 2 / config.petals!);
      ctx.beginPath();
      ctx.ellipse(0, -config.radius * 0.8, config.radius * 0.3, config.radius * 0.6, 0, 0, Math.PI * 2);
      ctx.fillStyle = config.innerColor!;
      ctx.fill();
      ctx.strokeStyle = config.color!;
      ctx.lineWidth = 2;
      ctx.stroke();
    }
    ctx.restore();
    
    // Central circle
    ctx.beginPath();
    ctx.arc(centerX, centerY, config.radius * 0.3, 0, Math.PI * 2);
    ctx.fillStyle = config.innerColor!;
    ctx.fill();
  };

  const drawLayer = (ctx: CanvasRenderingContext2D, layerIndex: number, visibleFlowers: number = -1) => {
    if (layerIndex === 0) {
      drawCentralMotif(ctx);
      return;
    }
    
    const layer = pookalamConfig.layers[layerIndex];
    const centerX = pookalamConfig.centerX;
    const centerY = pookalamConfig.centerY;
    const maxFlowers = visibleFlowers === -1 ? layer.flowerCount! : Math.min(visibleFlowers, layer.flowerCount!);
    
    for (let i = 0; i < maxFlowers; i++) {
      const angle = (i / layer.flowerCount!) * Math.PI * 2;
      const x = centerX + Math.cos(angle) * layer.radius;
      const y = centerY + Math.sin(angle) * layer.radius;
      
      let color = layer.color!;
      if (layer.type === 'alternating') {
        color = layer.colors![i % layer.colors!.length];
      }
      
      drawFlower(ctx, x, y, layer.flowerSize!, color);
    }
  };

  const clearCanvas = (ctx: CanvasRenderingContext2D) => {
    ctx.clearRect(0, 0, 600, 600);
    
    // Add subtle background gradient
    const gradient = ctx.createRadialGradient(300, 300, 50, 300, 300, 300);
    gradient.addColorStop(0, '#FEF3C7');
    gradient.addColorStop(1, '#F9FAFB');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, 600, 600);
  };

  const animatePookalam = async () => {
    if (animationRunning || !canvasRef.current) return;
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d')!;
    
    setAnimationRunning(true);
    setCurrentStep(0);
    setProgress(0);
    
    clearCanvas(ctx);
    
    for (let layerIndex = 0; layerIndex < pookalamConfig.layers.length; layerIndex++) {
      const statusMessages = [
        'Creating central motif...',
        'Placing inner jasmine flowers...',
        'Adding first alternating pattern...',
        'Completing marigold ring...',
        'Adding second alternating layer...',
        'Placing yellow flowers...',
        'Creating third pattern ring...',
        'Adding white flower layer...',
        'Completing marigold border...',
        'Finishing outer golden edge...'
      ];
      
      setStatusText(statusMessages[layerIndex]);
      
      if (layerIndex === 0) {
        // Draw central motif immediately
        clearCanvas(ctx);
        drawLayer(ctx, 0);
        await new Promise(resolve => setTimeout(resolve, 1000));
      } else {
        // Animate flowers appearing one by one
        const layer = pookalamConfig.layers[layerIndex];
        const flowerCount = layer.flowerCount!;
        const delayPerFlower = 50; // 50ms between each flower
        
        for (let flowerIndex = 0; flowerIndex <= flowerCount; flowerIndex++) {
          clearCanvas(ctx);
          
          // Draw all previous completed layers
          for (let prevLayer = 0; prevLayer < layerIndex; prevLayer++) {
            drawLayer(ctx, prevLayer);
          }
          
          // Draw current layer up to current flower
          if (flowerIndex > 0) {
            drawLayer(ctx, layerIndex, flowerIndex);
          }
          
          // Update progress within the current layer
          const layerProgress = flowerIndex / flowerCount;
          const overallProgress = ((layerIndex) + layerProgress) / pookalamConfig.layers.length * 100;
          setProgress(overallProgress);
          
          await new Promise(resolve => setTimeout(resolve, delayPerFlower));
        }
      }
      
      setCurrentStep(layerIndex + 1);
      const progressPercent = ((layerIndex + 1) / pookalamConfig.layers.length) * 100;
      setProgress(progressPercent);
    }
    
    setStatusText('Pookalam creation complete! 🌺');
    setAnimationRunning(false);
  };

  const resetPookalam = () => {
    if (animationRunning || !canvasRef.current) return;
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d')!;
    
    clearCanvas(ctx);
    setCurrentStep(0);
    setProgress(0);
    setStatusText('Ready to begin');
  };

  useEffect(() => {
    if (canvasRef.current) {
      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d')!;
      clearCanvas(ctx);
    }
  }, []);

  return (
    <div className="bg-card rounded-xl shadow-2xl p-8 mb-12 pookalam-glow">
      {/* Canvas Container */}
      <div className="text-center mb-8">
        <div className="relative inline-block">
          <canvas 
            ref={canvasRef}
            width="600" 
            height="600" 
            className="border-4 border-accent rounded-full shadow-lg max-w-full h-auto"
            data-testid="pookalam-canvas"
          />
        </div>
      </div>

      {/* Controls */}
      <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
        <Button 
          onClick={animatePookalam}
          disabled={animationRunning}
          className="bg-primary hover:bg-primary/90 text-primary-foreground px-8 py-3 font-medium shadow-lg hover:shadow-xl"
          data-testid="button-start-animation"
        >
          🌸 Create Pookalam
        </Button>
        
        <Button 
          onClick={resetPookalam}
          disabled={animationRunning}
          variant="secondary"
          className="bg-muted hover:bg-muted/80 text-muted-foreground px-6 py-3 font-medium"
          data-testid="button-reset-canvas"
        >
          🔄 Reset
        </Button>
      </div>

      {/* Animation Progress */}
      <div className="mt-6">
        <div className="text-center text-sm text-muted-foreground mb-2">
          <span data-testid="text-animation-status">{statusText}</span>
        </div>
        <Progress value={progress} className="w-full" data-testid="progress-animation" />
      </div>
    </div>
  );
}

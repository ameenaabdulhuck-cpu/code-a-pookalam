export function CulturalInfo() {
  return (
    <section className="bg-card rounded-xl shadow-lg p-8">
      <div className="max-w-4xl mx-auto text-center">
        <h2 className="font-serif text-3xl font-bold mb-6 text-primary" data-testid="text-cultural-title">
          The Art of Pookalam
        </h2>
        
        <div className="space-y-4 text-muted-foreground leading-relaxed">
          <p data-testid="text-cultural-description-1">
            Pookalam is a traditional floral carpet art form from Kerala, India, created during the Onam festival. 
            The word "pookalam" comes from two Malayalam words - "poo" (flower) and "kalam" (design).
          </p>
          
          <p data-testid="text-cultural-description-2">
            These intricate arrangements welcome King Mahabali, the legendary ruler who returns to visit 
            his people during Onam. Each flower carries symbolic significance - marigolds represent courage, 
            lotus symbolizes purity, and jasmine denotes hope.
          </p>
          
          <p data-testid="text-cultural-description-3">
            The traditional creation process starts from the center and works outward in concentric circles, 
            with new layers added daily during the 10-day festival period.
          </p>
        </div>
        
        <div className="mt-8 flex flex-wrap gap-3 justify-center">
          <span className="bg-primary/10 text-primary px-3 py-1 rounded-full text-sm font-medium" data-testid="tag-traditional-art">
            Traditional Art
          </span>
          <span className="bg-secondary/10 text-secondary px-3 py-1 rounded-full text-sm font-medium" data-testid="tag-cultural-heritage">
            Cultural Heritage
          </span>
          <span className="bg-accent/20 text-accent-foreground px-3 py-1 rounded-full text-sm font-medium" data-testid="tag-onam-festival">
            Onam Festival
          </span>
        </div>
      </div>
    </section>
  );
}

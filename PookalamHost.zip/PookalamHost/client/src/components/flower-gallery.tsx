export function FlowerGallery() {
  const flowers = [
    {
      name: "Marigold",
      image: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      meaning: "Courage and prosperity",
      color: "text-primary"
    },
    {
      name: "Hibiscus", 
      image: "https://images.unsplash.com/photo-1597848212624-e6f9a4b0c10e?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      meaning: "Beauty and grace",
      color: "text-secondary"
    },
    {
      name: "Jasmine",
      image: "https://images.unsplash.com/photo-1595846519845-68e298c2efe1?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400", 
      meaning: "Purity and hope",
      color: "text-foreground"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
      {flowers.map((flower, index) => (
        <div key={flower.name} className="bg-card rounded-lg p-6 shadow-lg" data-testid={`card-flower-${index}`}>
          <div className="text-center">
            <img 
              src={flower.image} 
              alt={`${flower.name} flowers`} 
              className="w-full h-32 object-cover rounded-lg mb-4"
              data-testid={`img-flower-${flower.name.toLowerCase()}`}
            />
            <h3 className={`font-serif text-xl font-semibold mb-2 ${flower.color}`} data-testid={`text-flower-name-${flower.name.toLowerCase()}`}>
              {flower.name}
            </h3>
            <p className="text-muted-foreground text-sm" data-testid={`text-flower-meaning-${flower.name.toLowerCase()}`}>
              {flower.meaning}
            </p>
          </div>
        </div>
      ))}
    </div>
  );
}

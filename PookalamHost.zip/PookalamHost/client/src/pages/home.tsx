import { PookalamCanvas } from "@/components/pookalam-canvas";
import { CulturalInfo } from "@/components/cultural-info";

export default function Home() {
  return (
    <div className="bg-background text-foreground font-sans">
      {/* Header */}
      <header className="relative py-12 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <div className="decorative-border h-1 w-32 mx-auto mb-8 rounded-full"></div>
          
          <h1 className="font-display text-3xl md:text-5xl font-normal mb-4 bg-gradient-to-r from-primary via-accent to-secondary bg-clip-text text-transparent uppercase tracking-wider" data-testid="text-site-title">
            CODE-A-POOKALAM
          </h1>
          
          <p className="text-muted-foreground text-lg md:text-xl max-w-2xl mx-auto leading-relaxed">
            Experience the traditional art of Kerala's flower carpet through digital craftsmanship
          </p>
          
          <div className="decorative-border h-1 w-32 mx-auto mt-8 rounded-full"></div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-5xl mx-auto px-4 py-8">
        {/* Pookalam Canvas Section */}
        <PookalamCanvas />
        
        {/* Cultural Information */}
        <CulturalInfo />
      </main>
    </div>
  );
}

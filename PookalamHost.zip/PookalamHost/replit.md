# Code-a-Pookalam

## Overview

Code-a-Pookalam is a cultural web application that celebrates the traditional Kerala art of Pookalam (floral carpet design) through digital craftsmanship. The application provides an interactive canvas for creating digital Pookalam designs while educating users about the cultural significance of this traditional art form associated with the Onam festival.

The project is built as a full-stack TypeScript application featuring a React frontend with an Express backend, designed to showcase the beauty and meaning of Kerala's floral carpet traditions in a modern, interactive format.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript, using Vite as the build tool and development server
- **Routing**: Wouter for lightweight client-side routing
- **UI Components**: Shadcn/ui component library built on Radix UI primitives with Tailwind CSS for styling
- **State Management**: TanStack Query for server state management and caching
- **Styling**: Tailwind CSS with custom color schemes and typography, featuring Kerala-inspired warm color palette

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Structure**: RESTful API design with `/api` prefix for all endpoints
- **Development**: Hot reloading with Vite integration for seamless development experience
- **Storage Interface**: Abstract storage interface allowing for multiple implementations (currently in-memory storage)

### Data Storage Solutions
- **ORM**: Drizzle ORM for type-safe database operations
- **Database**: PostgreSQL configured through Neon Database serverless
- **Schema**: User management system with username/password authentication
- **Development Storage**: In-memory storage implementation for rapid prototyping

### Authentication and Authorization
- **Session Management**: PostgreSQL-based session storage using connect-pg-simple
- **User Model**: Simple username/password authentication system
- **Schema Validation**: Zod for runtime type checking and validation

### Project Structure
- **Monorepo**: Shared TypeScript types and schemas between client and server
- **Client**: React application in `/client` directory with component-based architecture
- **Server**: Express API in `/server` directory with modular route organization
- **Shared**: Common types and database schemas in `/shared` directory

### Key Features
- **Interactive Canvas**: HTML5 Canvas-based Pookalam creation tool with layered design system
- **Cultural Education**: Information sections about traditional Pookalam art and Onam festival
- **Flower Gallery**: Visual showcase of traditional flowers used in Pookalam with cultural meanings
- **Responsive Design**: Mobile-first approach with adaptive layouts

### Build and Deployment
- **Development**: Concurrent client and server development with hot reloading
- **Production Build**: Vite bundling for client, esbuild for server optimization
- **Asset Management**: Static asset serving with proper caching headers

## External Dependencies

### UI and Styling
- **Shadcn/ui**: Complete component library with Radix UI primitives
- **Tailwind CSS**: Utility-first CSS framework with custom theming
- **Lucide React**: Icon library for consistent iconography
- **Google Fonts**: Custom typography with Playfair Display and Inter fonts

### Database and ORM
- **Neon Database**: Serverless PostgreSQL hosting
- **Drizzle ORM**: Type-safe database toolkit with schema migrations
- **Drizzle Kit**: CLI tools for database schema management

### React Ecosystem
- **TanStack Query**: Server state management and caching
- **React Hook Form**: Form handling with validation
- **Wouter**: Lightweight routing library
- **Date-fns**: Date manipulation utilities

### Development Tools
- **Vite**: Build tool and development server
- **ESBuild**: Fast bundler for production builds
- **TypeScript**: Static type checking
- **Replit Integration**: Development environment optimization plugins